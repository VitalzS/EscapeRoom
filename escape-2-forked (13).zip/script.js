// https://www.w3schools.com/Jsref/met_document_getelementbyid.asp
// https://www.w3schools.com/jsref/prop_element_classlist.asp

function keyd() {
  document.getElementById("top-left").classList.remove("dark-grey");
  document.getElementById("top-left").classList.add("red");
  document.getElementById("top-left").src = "images/tombstone.gif";
}

function driverd() {
  document.getElementById("bottom-right").classList.remove("dark-grey");
  document.getElementById("bottom-right").classList.add("green");
  document.getElementById("bottom-right").src = "images/witch.gif";
}

function remove_image() {
  document.getElementById("key1").remove();
}
function remove_image1() {
  document.getElementById("driv").remove();
}

function resetAll() {
  document.getElementById("br").classList.remove("green");
  document.getElementById("br").classList.add("dark-grey");
  document.getElementById("tl").classList.remove("red");
  document.getElementById("tl").classList.add("dark-grey");
}

var clicks1 = 0;
var clicks2 = 0;
var clicks6 = 0;

var modal = document.getElementById("myModal");

// Get the button that opens the modal
var bux = document.getElementById("vent1");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

bux.onclick = function () {
  modal.style.display = "block";
};

// When the user clicks on <span> (x), close the modal
span.onclick = function () {
  modal.style.display = "none";
};

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};
