// https://www.w3schools.com/Jsref/met_document_getelementbyid.asp
// https://www.w3schools.com/jsref/prop_element_classlist.asp

var clicks11 = 0;
var clicks6 = 0;
var clicks3 = 0;
var clicks2 = 0;
var clicks1 = 0;

function remove_image() {
  document.getElementById("key1").remove();
}
function remove_image1() {
  document.getElementById("driv").remove();
  clicks11 = clicks11 + 1;
  console.log(clicks11);
}
function fscrew() {
  if (clicks11 == 1) {
    document.getElementById("ones").remove();
    clicks6 = 1;
  } else if (clicks11 <= 2) {
    clicks11 == 0;
    clicks2 == 0;
    clicks1 == 0;
  }
  console.log(clicks11);
  console.log(clicks6);
  console.log(clicks3);
  console.log(clicks2);
  console.log(clicks1);
  end();
}
function sscrew() {
  if (clicks6 == 1) {
    document.getElementById("twos").remove();
    clicks2 = 1;
  } else if (clicks6 <= 2) {
    clicks11 == 0;
    clicks6 == 0;
    clicks1 == 0;
  }
  console.log(clicks11);
  console.log(clicks6);
  console.log(clicks3);
  console.log(clicks2);
  console.log(clicks1);
  end();
}
function tscrew() {
  if (clicks2 == 1) {
    document.getElementById("threes").remove();
    clicks1 = 1;
  } else if (clicks2 <= 2) {
    clicks11 == 0;
    clicks6 == 0;
    clicks1 == 0;
  }
  console.log(clicks11);
  console.log(clicks6);
  console.log(clicks3);
  console.log(clicks2);
  console.log(clicks1);
  end();
}
function lscrew() {
  if (clicks1 == 1) {
    document.getElementById("fours").remove();
    //document.getElementById("my_song").play();
    clicks3 = 3;
  } else if (clicks1 <= 2) {
    clicks11 == 0;
    clicks6 == 0;
    clicks2 == 0;
  }
  console.log(clicks11);
  console.log(clicks6);
  console.log(clicks3);
  console.log(clicks2);
  console.log(clicks1);
  end();
}

function end() {
  if (clicks3 == 3) {
    console.log("end");
    document.getElementById("vent1").setAttribute("src", "images/hole.png");
    document.getElementById("vent1").setAttribute("onclick", "showCameron()");
    document.getElementById("vent1").src = "images/hole.png";
    document.getElementById("my_song").play();
  } else {
    console.log("notdone");
  }
}

var modal = document.getElementById("myModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

function showModal() {
  modal.style.display = "block";
}
function showCameron() {
  window.location.href = "http://www.w3schools.com";
}
// When the user clicks on <span> (x), close the modal
span.onclick = function () {
  modal.style.display = "none";
};

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};
