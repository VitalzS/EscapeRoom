// https://www.w3schools.com/Jsref/met_document_getelementbyid.asp
// https://www.w3schools.com/jsref/prop_element_classlist.asp

function turnRedGif() {
  document.getElementById("top-left").classList.remove("dark-grey");
  document.getElementById("top-left").classList.add("red");
  document.getElementById("top-left").src = "images/tombstone.gif";
}

function turnGreenGif() {
  document.getElementById("bottom-right").classList.remove("dark-grey");
  document.getElementById("bottom-right").classList.add("green");
  document.getElementById("bottom-right").src = "images/witch.gif";
}

function resetAll() {
  document.getElementById("br").classList.remove("green");
  document.getElementById("br").classList.add("dark-grey");
  document.getElementById("tl").classList.remove("red");
  document.getElementById("tl").classList.add("dark-grey");
}

function myCustomFunction() {
  document.getElementById("top-left").classList.remove("dark-grey");
  document.getElementById("top-right").classList.add("dark-grey");
  document.getElementById("top-left").classList.add("black");
  document.getElementById("top-right").classList.remove("black");
  document.getElementById("bottom-left").classList.remove("dark-grey");
  document.getElementById("bottom-right").classList.add("black");
  document.getElementById("bottom-left").classList.remove("blue");
  document.getElementById("bottom-right").classList.add("black");
}
